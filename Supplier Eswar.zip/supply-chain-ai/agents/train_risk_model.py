import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import joblib
import os

os.makedirs("models", exist_ok=True)

np.random.seed(42)
rows = []

for _ in range(2000):
    uptime = np.random.uniform(0.6, 1.0)
    labor = np.random.uniform(0.6, 1.0)
    delay = np.random.uniform(0.0, 0.4)
    prod_rate = np.random.uniform(30, 150)

    risk_signal = (1 - uptime) + (1 - labor) + delay
    disrupted = 1 if risk_signal > 0.9 else 0

    rows.append([uptime, labor, delay, prod_rate, disrupted])

df = pd.DataFrame(
    rows,
    columns=["uptime", "labor", "delay", "prod_rate", "disrupted"]
)

X = df[["uptime", "labor", "delay", "prod_rate"]]
y = df["disrupted"]

model = RandomForestClassifier(
    n_estimators=100,
    max_depth=5,
    random_state=42
)

model.fit(X, y)

joblib.dump(model, "models/risk_model.pkl")
print("✅ ML risk model trained and saved")
