import joblib
import pandas as pd

class PredictionAgent:
    def __init__(self):
        self.model = joblib.load("models/risk_model.pkl")

    def predict_failure_risk(self, supplier):
        X = pd.DataFrame([{
            "uptime": supplier.machine_uptime,
            "labor": supplier.labor_availability,
            "delay": supplier.transport_delay,
            "prod_rate": supplier.production_rate
        }])

        probability = self.model.predict_proba(X)[0][1]
        supplier.risk_score = round(float(probability), 2)
        return supplier
