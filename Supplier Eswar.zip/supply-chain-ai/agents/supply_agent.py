class SupplyAgent:
    def update_expected_inventory(self, supplier):
        supplier.expected_inventory = (
            supplier.production_rate *
            supplier.machine_uptime *
            supplier.labor_availability *
            (1 - supplier.transport_delay)
        )
        return supplier
