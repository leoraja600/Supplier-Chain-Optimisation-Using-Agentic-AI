import streamlit as st
import requests
import time
import pandas as pd
import networkx as nx

# ================= PAGE CONFIG =================
st.set_page_config(
    page_title="Phantom Stock Command Center",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ================= DARK MODE THEME =================
st.markdown("""
<style>
.stApp { background-color: #0e1117; color: #e6e6e6; }
h1,h2,h3 { color: #ffffff; }
section[data-testid="stSidebar"] { background-color: #161a23; }
[data-testid="stDataFrame"] { background-color: #161a23; }
.stAlert { background-color: #1f2430 !important; border-left: 6px solid #ff4b4b !important; }
.stSuccess { background-color: #1f3d2b !important; border-left: 6px solid #2ecc71 !important; }
.stWarning { background-color: #3b2f1c !important; border-left: 6px solid #f1c40f !important; }
</style>
""", unsafe_allow_html=True)

# ================= SIDEBAR =================
st.sidebar.title("⚙️ Controls")
refresh_rate = st.sidebar.slider("Refresh interval (seconds)", 2, 10, 3)

st.sidebar.markdown("""
**Legend**
🔴 High Risk  
🟡 Medium Risk  
🟢 Healthy  
""")

# ================= HELPERS =================
def risk_label(score):
    if score >= 0.7:
        return "🔴 HIGH"
    elif score >= 0.4:
        return "🟡 MEDIUM"
    else:
        return "🟢 LOW"

def risk_color(score):
    if score >= 0.7:
        return "red"
    elif score >= 0.4:
        return "orange"
    else:
        return "green"

def build_graph(df):
    G = nx.DiGraph()
    for _, r in df.iterrows():
        G.add_node(r["id"], risk=r["risk_score"])
    for _, r in df.iterrows():
        for d in r["dependencies"]:
            G.add_edge(d, r["id"])
    return G

# 🔥 FORCE 5 OVALS PER ROW
def render_graph(G):
    dot = """
    digraph G {
        rankdir=LR;
        nodesep=0.3;
        ranksep=0.5;
        node [
            shape=ellipse,
            style=filled,
            fontcolor=white,
            fontsize=9,
            width=1.2,
            height=0.45,
            fixedsize=true
        ];
        edge [
            color=gray,
            arrowsize=0.6
        ];
    }
    """

    nodes = list(G.nodes(data=True))

    # ---- force 5 nodes per row ----
    for i in range(0, len(nodes), 5):
        dot += "{ rank=same; "
        for n, _ in nodes[i:i+5]:
            dot += f'"{n}"; '
        dot += "}\n"

    # ---- node styles ----
    for n, d in nodes:
        dot += f'"{n}" [fillcolor={risk_color(d["risk"])} label="{n}\\n{round(d["risk"],2)}"];\n'

    # ---- edges ----
    for u, v in G.edges():
        dot += f'"{u}" -> "{v}";\n'

    dot += "}"
    return dot

# ================= LIVE LOOP =================
placeholder = st.empty()

while True:
    try:
        data = requests.get("http://localhost:8000/run").json()
    except:
        st.error("❌ Backend not running. Start FastAPI.")
        break

    df = pd.DataFrame(data["suppliers"])
    if "dependencies" not in df.columns:
        df["dependencies"] = [[] for _ in range(len(df))]

    # 🔥 risk-first sorting
    df = df.sort_values("risk_score", ascending=False)
    df["Risk Level"] = df["risk_score"].apply(risk_label)

    with placeholder.container():

        # ===== HEADER =====
        st.markdown("## 🧠 Phantom Stock Command Center")
        st.caption("Executive view · AI-driven · Early disruption intelligence")

        # ===== CRITICAL RISKS FIRST =====
        critical = df[df["risk_score"] >= 0.7]
        if not critical.empty:
            st.markdown("### 🚨 CRITICAL RISKS")
            for _, r in critical.iterrows():
                st.error(
                    f"{r['id']} (Tier {r['tier']}) | "
                    f"Risk {r['risk_score']} | Phantom {r['phantom_index']}"
                )
        else:
            st.success("All suppliers currently stable")

        # ===== SUPPLIER TABLE =====
        st.markdown("### 📦 Supplier Intelligence (Risk-Sorted)")
        st.dataframe(
            df[
                ["id","tier","Risk Level",
                 "reported","expected",
                 "phantom_index","risk_score"]
            ],
            use_container_width=True
        )

        # ===== ALERTS =====
        st.markdown("### ⚠️ Early Warnings")
        if data["alerts"]:
            for a in data["alerts"]:
                st.warning(
                    f"{a['path']} → impact in {a['impact_days']} days "
                    f"(confidence {a['confidence']}%)"
                )
        else:
            st.info("No upstream propagation detected")

        # ===== NETWORK GRAPH (BOTTOM) =====
        # ---------- NETWORK GRAPH ----------
st.markdown("### 🌐 Supply Chain Risk Map (5 per row)")
G = build_graph(df)
st.graphviz_chart(render_graph(G), use_container_width=True)
